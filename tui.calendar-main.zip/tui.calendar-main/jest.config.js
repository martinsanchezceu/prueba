module.exports = {
  projects: ['<rootDir>/libs/date/jest.config.js', '<rootDir>/apps/calendar/jest.config.js'],
};
