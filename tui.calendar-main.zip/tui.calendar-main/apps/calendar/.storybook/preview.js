import 'preact/debug';
import '@src/css/index.css';
import 'tui-date-picker/dist/tui-date-picker.css';
import 'tui-time-picker/dist/tui-time-picker.css';

export const parameters = {
  layout: 'fullscreen',
};
