import { addons } from '@storybook/addons';
import calendarTheme from './theme';

addons.setConfig({
  theme: calendarTheme,
});
