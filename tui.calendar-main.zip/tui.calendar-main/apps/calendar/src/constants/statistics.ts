export const GA_TRACKING_ID = 'UA-129951699-1';
