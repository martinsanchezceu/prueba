export const INVALID_DATETIME_FORMAT = 'Invalid DateTime Format';
export const INVALID_TIMEZONE_NAME = 'Invalid IANA Timezone Name';
export const INVALID_VIEW_TYPE = 'Invalid View Type';
