export const MESSAGE_PREFIX = '@toast-ui/calendar: ';
