export const DEFAULT_VISIBLE_WEEKS = 6;

export enum CellBarType {
  header = 'header',
  footer = 'footer',
}
