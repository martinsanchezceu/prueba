export const TEST_IDS = {
  NOW_INDICATOR: 'timegrid-now-indicator',
  NOW_INDICATOR_LABEL: 'timegrid-now-indicator-label',
};
