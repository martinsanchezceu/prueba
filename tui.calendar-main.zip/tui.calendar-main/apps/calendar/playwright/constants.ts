export enum ClickDelay {
  Immediate = 1,
  Short = 100,
  Long = 300,
}
