module.exports = {
  "**/*.js": "eslint --fix",
}
